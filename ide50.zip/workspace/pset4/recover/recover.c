#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <cs50.h>

typedef uint8_t  BYTE;

typedef struct
{
     BYTE JPEGblock[512];
} __attribute__((__packed__))
JPEG;

bool is_header(JPEG buffer);

int main(int argc, char *argv[])
{
    // ensure proper usage
    if (argc != 2)
    {
        fprintf(stderr, "Usage: ./recover image\n");
        return 1;
    }

    char *infile = argv[1];

    // open input file
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", infile);
        return 2;
    }
    //find the size of the file
    fseek(inptr,0L,SEEK_END);
    int size = ftell(inptr)/512;
    rewind(inptr);

    //set up variables for use in the for loop
    bool file_open = false;
    char *filename = malloc(sizeof(int));
    JPEG buffer;
    FILE *img;


    //This loop iterates over each block in the memory card, stopping at the end of the card
    for (int j = 0, i = 0; j < size; j++)
    {

        //read data from input file and store to struct buffer 1 block at a time
        fread(&buffer, 512, 1, inptr);

        //if a new JPEG is indicated
        if(is_header(buffer) == true)
        {

            //if a previous image file was open then close it
            if (file_open == true)
            {
                fclose(img);
            }

            //open a new JPEG file
            sprintf(filename, "%03i.jpg",i);
            img = fopen(filename, "w");

            file_open = true;

            i++;
            fwrite(&buffer, 1, 512, img);

        }

        //if new JPEG not indicated, but a JPG is currently open
        else if (file_open == true && is_header(buffer) == false)
        {
            fwrite(&buffer, 512, 1, img);
        }

    }
    free(filename);
    fclose(img);
    fclose(inptr);
    return 0;
}

bool is_header(JPEG buffer)
{
    if (buffer.JPEGblock[0] == 0xff && buffer.JPEGblock[1] == 0xd8 &&
    buffer.JPEGblock[2] == 0xff &&
    (buffer.JPEGblock[3] >= 0xe0 && buffer.JPEGblock[3] <= 0xef))
    {
        return true;
    }
    else
    {
        return false;
    }
}




