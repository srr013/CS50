
#include <stdio.h>
#include <stdlib.h>


#include "bmp.h"

int main(int argc, char *argv[])
{
    // ensure proper usage
    if (argc != 4)
    {
        fprintf(stderr, "Usage: ./resize f(0.0 - 100.0) infile outfile\n");
        return 1;
    }

    // remember filenames
    double f = atof(argv[1]);
    char *infile = argv[2];
    char *outfile = argv[3];

    //check that f is >=0 and <=100
    if (f < 0 || f > 100)
    {
        fprintf(stderr, "Usage: ./resize f(0.0 - 100.0) infile outfile\n");
        return 1;
    }

    // open input file
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", infile);
        return 2;
    }

    // open output file
    FILE *outptr = fopen(outfile, "w");
    if (outptr == NULL)
    {
        fclose(inptr);
        fprintf(stderr, "Could not create %s.\n", outfile);
        return 3;
    }

    // read infile's BITMAPFILEHEADER
    BITMAPFILEHEADER bf;
    BITMAPFILEHEADER new_bf;
    fread(&bf, sizeof(BITMAPFILEHEADER), 1, inptr);

    // read infile's BITMAPINFOHEADER
    BITMAPINFOHEADER bi;
    BITMAPINFOHEADER new_bi;
    fread(&bi, sizeof(BITMAPINFOHEADER), 1, inptr);

    //read the same data into new_bi/bf
    fseek(inptr,0, SEEK_SET);
    fread(&new_bf, sizeof(BITMAPFILEHEADER), 1, inptr);
    fread(&new_bi, sizeof(BITMAPINFOHEADER), 1, inptr);

    // ensure infile is (likely) a 24-bit uncompressed BMP 4.0
    if (bf.bfType != 0x4d42 || bf.bfOffBits != 54 || bi.biSize != 40 ||
        bi.biBitCount != 24 || bi.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        fprintf(stderr, "Unsupported file format.\n");
        return 4;
    }

    //update new_bf with appropriate width, height data

    new_bi.biWidth = bi.biWidth * f;
    new_bi.biHeight = bi.biHeight * f;
    // determine padding for scanlines
    int padding =  (4 - (bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    int new_padding = (4 - (new_bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    //update new_bf with appropriate size data
    new_bi.biSizeImage = abs(new_bi.biHeight) * ((new_bi.biWidth *sizeof(RGBTRIPLE))+new_padding);
    new_bf.bfSize = new_bi.biSizeImage + 54;



    // write outfile's BITMAPFILEHEADER
    fwrite(&new_bf, sizeof(BITMAPFILEHEADER), 1, outptr);

    // write outfile's BITMAPINFOHEADER
    fwrite(&new_bi, sizeof(BITMAPINFOHEADER), 1, outptr);



    // temporary storage
    RGBTRIPLE triple;

    //create a value that will skip some data within the for loops if a decimal is passed in.
    double skip;
    if (f < 1)
    {
        skip = 1/f;
    }
    else
    {
        skip = 1;
    }

    // iterate over infile's scanlines. Pass "skip" lines if a decimal is passed in.
    for (double i = 0, biHeight = abs(bi.biHeight); i < biHeight; i = i + skip)
    {
        int h = 0;
        long curr_line;

        //duplicate lines as needed. Duplication never occurs with decimals.
        for (int k = 0 ; k < f; k++)
        {
            curr_line = ftell(inptr);

            // iterate over pixels in scanline. Pass by every "skip" pixels if a decimal is passed in.
            for (double j = 0; j < bi.biWidth; j = j + skip)
            {
                // read RGB triple from infile
                fread(&triple, sizeof(RGBTRIPLE), 1, inptr);

                //write pixel to output. If decimal this will only write 1 pixel
                for (int l = 0; l < f; l++)
                {
                    if (f < 1 && j < bi.biWidth - 1 && i < abs(bi.biHeight) -1)
                    {
                    fwrite(&triple, sizeof(RGBTRIPLE), 1, outptr);
                    }
                    else if (f >= 1)
                    {
                    fwrite(&triple, sizeof(RGBTRIPLE), 1, outptr);
                    }

                }
                //if f is a decimal then move the cursor by skip pixels
                if (f < 1 && j < bi.biWidth - 1)
                {
                    fseek(inptr,(skip-1)*sizeof(RGBTRIPLE),SEEK_CUR);
                    curr_line = ftell(inptr);
                }
            }

            // skip over padding, if any
            fseek(inptr, padding, SEEK_CUR);

            //if duplicating line then reset infile pointer. Never duplicate when a decimal is passed in.
            if (h < f-1)
            {
                fseek(inptr, curr_line, SEEK_SET);
                h++;
            }
            else
            {
                curr_line = ftell(inptr);
            }

            // add padding to the new file
            for (int m = 0; m < new_padding; m++)
            {
                fputc(0x00, outptr);
            }

            if (f < 1)
            {
                fseek(inptr,((bi.biWidth*sizeof(RGBTRIPLE))+padding)*(skip-1),SEEK_CUR);
                curr_line = ftell(inptr);
            }

        }



    }

    // close infile
    fclose(inptr);

    // close outfile
    fclose(outptr);

    // success
    return 0;
}