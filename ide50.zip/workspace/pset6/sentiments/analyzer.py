import nltk
import io

class Analyzer():
    """Implements sentiment analysis."""
    positives = []
    negatives = []

#need to implement same load for negatives
    def __init__(self, positives, negatives):
        """Initialize Analyzer."""

        positives_file = open(positives)
        positives_file = positives_file.readlines()
        for i in positives_file:

            if i.startswith(';'):
                pass
            else:
                i = i.strip(" \n")
                self.positives.append(i)

        negatives_file = open(negatives)
        negatives_file = negatives_file.readlines()
        for j in negatives_file:

            if j.startswith(';'):
                pass
            else:
                j = j.strip(" \n")
                self.negatives.append(j)

    def analyze(self, text):
        """Analyze text for sentiment, returning its score."""
        tokenizer = nltk.tokenize.TweetTokenizer()
        tokens = tokenizer.tokenize(text)

        score = 0
        j = 0

        for i in tokens:
            i = i.lower()
            while j < len(self.positives):
                if i == self.positives[j]:
                    score += 1
                    break
                if i == self.negatives[j]:
                    score -= 1
                    break
                else:
                    j += 1
            j = 0

        return score