import cs50

# get the credit card number
while True:
    print("Number: ", end="")
    n = cs50.get_float()

    #check length
    if n > 100000000000000:
        break

def sum_digits(n):
    i = 0
    j = 0

    while 1 < n:

        i += int(n % 10)

        n = int(n/10)

        if ((n % 10)*2) > 9:
            j += int(1 + (((n % 10)*2) % 10))
        else:
            j = j + ((n % 10)*2)

        n = n/10

    card_total = int(i) +int(j)

    if card_total % 10 == 0:
        return True
    else:
        return False


def card_type(n):
    while n > 100:
        n = int(n/10)

    if n == 37 or n == 34:
        return "AMEX"
    elif n > 50 and n < 56:
        return "MASTERCARD"
    elif n >39 and n <50:
        return "VISA"
    else:
        return "INVALID"

if sum_digits(n) == True:
    print(card_type(n))
else:
    print("INVALID")






