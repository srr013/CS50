import cs50

#get input from user for height
print("Height: ", end="")
s = cs50.get_int()


#set counter variable to control height
i = 0

#iterate over each level, printing space or # as needed
while i < s:
    j = s-i
    k = i+1

    print(" "*j, end="")
    print("#"*k, end="")

    print("  ", end="")

    print("#"*k)

    i += 1

