import cs50
import crypt
import sys
import string


if len(sys.argv) != 2:
    print("Usage: crack.py hash")
    exit(1)

hashed_pw = sys.argv[1]
salt = hashed_pw[:2]



def brute_force(hashed_pw, salt):

    letters = string.ascii_lowercase + string.ascii_uppercase
    i = 0
    j = 0
    k = 0
    l = 0

    while i < len(letters):
        check = letters[i]
        check_hash = crypt.crypt(check, salt)

        if check_hash == hashed_pw:
            return check
            exit()
        else:
            while j < len(letters):
                check = letters[i] + letters[j]
                check_hash = crypt.crypt(check, salt)

                if check_hash == hashed_pw:
                    return check
                    exit()

                else:
                    while k < len(letters):
                        check = letters[i] + letters[j] + letters[k]
                        check_hash = crypt.crypt(check, salt)

                        if check_hash == hashed_pw:
                            return check
                            exit()


                        else:
                            while l < len(letters):
                                check = letters[i]+ letters[j] + letters[k] + letters[l]
                                check_hash = crypt.crypt(check, salt)

                                if check_hash == hashed_pw:
                                    return check
                                    exit()
                                else:
                                    l += 1
                        l = 0
                        k += 1
                l = 0
                k = 0
                j += 1
        l = 0
        k = 0
        j = 0
        i += 1

    print ("None found")

print("The password is: ", brute_force(hashed_pw, salt))

