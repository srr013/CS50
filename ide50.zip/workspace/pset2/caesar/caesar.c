#include <ctype.h>
#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <stdlib.h>

void encode(string p, int k);

int main(int argc, string argv[])
{
    if (argc == 2)
    {
        int k = atoi(argv[1]);
        string plain_text = get_string("plaintext: ");
        encode(plain_text, k);

    }
    else
    {
        printf("Usage: ./ceasar k\n");
        return 1;
    }
}

void encode(string p, int k)
{
    printf("ciphertext: ");
    for (int i = 0, n = strlen(p); i < n; i++)
    {
        int c = p[i];

        if (k > 26)
        {
            k = k % 26;
        }

        if (p[i] <65 || (p[i] > 90 && p[i] < 97) || p[i] > 122)
        {
            c = p[i];
        }
        else
        {
            c = p[i] + k;
        }

        if (p[i] > 64 && p[i] < 91)
        {
            if (c > 90)
            {
                c = c - 26;
            }
        }

        if (p[i] > 96 && p[i] < 123)
        {
            if (c > 122)
            {
                c = c - 26;
            }
        }

        p[i] = (char) c;
        printf("%c", p[i]);

    }
    printf("\n");
}

