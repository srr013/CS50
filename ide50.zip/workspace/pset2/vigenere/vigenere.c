#include <ctype.h>
#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <stdlib.h>

void encode(string p, string k);
bool check_alpha(string k);

int main(int argc, string argv[])
{
    string k = argv[1];

    //check if non-alpha
    if (argc != 2)
    {
        printf("Usage: ./cvignere k(alpha only)\n");
        return 1;
    }
    if (check_alpha(k) == false)
    {
        printf("Usage: ./cvignere k(alpha only)\n");
        return 1;
    }
    //ensure the appropriate # of args are passed in
    else if (argc == 2)
    {
        string plain_text = get_string("plaintext : ");
        encode(plain_text, k);

    }
    //quit if not 2 args
    else
    {
        printf("Usage: ./cvignere k(alpha only)\n");
        return 1;
    }
}

//function to ensure the command line was only alpha
bool check_alpha(string k)
{
    bool alpha;

    for (int i = 0, n = strlen(k); i < n; i++)
    {
        if (isalpha(k[i]) == false)
        {
            return false;
            exit(EXIT_SUCCESS);
        }
        else
        {
            alpha = true;
        }
    }
    return alpha;
}

void encode(string p, string k)
{
    printf("ciphertext: ");
    //look at each letter in the plain text
    for (int i = 0, j = 0, l = strlen(p); j < l; j++)
    {
        //reset cipher if it reaches end
        if (i >= strlen(k))
        {
            i = 0;
        }

        //convert the coding system to a number to be added to the plain text chars.
        char code = k[i] - 65;
        if (code > 26)
        {
            code = code-32;
        }
        //check for non-alpha and leave those as-is
        char character = p[j];
        if ((character > 90 && character < 97)|| character <65 || character > 122)
        {
        }
        else
        //update the plain text chars via the code.
        {
            if (character < 91)
            {
                character = character + (char) code;
                if (character > 90)
                {
                    character = character - 26;
                }
            }
            if (character > 96)
            {
                if (character + code > 127)
                {
                    character = character - 26;
                }
                character = character + (char)code;
                //check if code extends past z
                if (character > 122)
                {
                    character = character - 26;
                }
            }
        }
        i++;
        printf("%c", character);
    }
    printf("\n");
}
