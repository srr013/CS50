#include <ctype.h>
#include <stdio.h>
#include <cs50.h>
#include <string.h>

string get_name(void);
void parse_name(string s);

int main(void)
{
    string name = get_name();
    parse_name(name);
    printf("\n");
}

string get_name(void)
{
    return get_string();
}

void parse_name(string s)
{
    char *initials;
    initials = strtok (s," ");
    while (initials != NULL)
    {
        printf ("%c",toupper(initials[0]));
        initials = strtok (NULL, " ");
    }
}

