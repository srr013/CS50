#include <ctype.h>
#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <stdlib.h>
#define _GNU_SOURCE
#include <crypt.h>

void crack(string hash);
char get_salt(string hash);

int main(int argc, string argv[])
{
    if (argc == 2)
    {
        string hash = argv[1];
        char salt = get_salt(hash);
        printf("%c is salt", salt);
    }
    else
    {
        printf("Usage: ./crack hash\n");
        return 1;
    }
}

char get_salt(string hash)
{
    char one = hash[0];
    char two = hash[1];
    printf("char %c and char %c", one, two);
    return one;

}



//salt = 50
//char x = crypt(a, salt);
  //          char y = hash[i+2];
    //        printf("%s is x", x);
      //      string test = crypt(y, salt);
        //    printf("%s is test", test);
          //  if ((char) test == (char) x)
