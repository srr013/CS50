/**
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <cs50.h>
#include <ctype.h>

#include "dictionary.h"

//assign root node for use in all functions
node * root = NULL;
unsigned int word_count;

/**
 * Returns true if word is in dictionary else false.
 */
 //Should be complete
bool check(const char *word)
{
    //lookup will be used to hold the lower case word
    char *lookup;
    lookup = malloc(strlen(word) * sizeof(char));

    // Send word to lower case
    for (int i = 0; i < strlen(word); i++)
    {
        lookup[i] = tolower(word[i]);
    }

    //now check the word against the dictionary
    node *pointer = root;

    for (int c = 0; c < strlen(word) ; c++)
    {
        int x = lookup[c] - 97;
        if (lookup[c] == '\'')
        {
            x = 26;
        }
        //return false if some letter does not exist in the trie
        if (pointer -> children[x] == NULL)
        {
            free(lookup);
            return false;
        }
        //move on to next letter if it exists
        else
        {
            pointer = pointer -> children[x];
        }

        //if all letters in the word exist check to see if it's marked as a word
        if (c == strlen(word)-1)
        {
            if (pointer -> is_word == true)
            {
                free(lookup);
                return true;
            }
            else
            {
                free(lookup);
                return false;
            }
        }

    }

    free(lookup);
    return false;
}

/**
 * Loads dictionary into memory. Returns true if successful else false.
 */

bool load(const char *dictionary)
{
    // every node contains an array of node pointers (one for every letter + '\")
    //for every new node created malloc space in memory for it and check to ensure it doesnt return NULL
    //when a word is entered into the trie set "is_word" to true

    //open the file for use. Throw an error if the file doesnt open.
    FILE *dict = fopen(dictionary,"r");
    if (dict == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", dictionary);
        return 2;
    }

    //set up variables to be used in the loop
    char word[LENGTH+1];
    int index = 0;
    root = calloc(1,sizeof(node));
    if (root == NULL)
    {
        return false;
    }


    //loop to go over full dictionary
    for (int i = fgetc(dict); i != EOF; i = fgetc(dict))
    {
        if (isalnum(i)|| i == '\'')
        {
            word[index] = i;
            index++;
        }
        //word is complete. Pass to trie
        else if(index > 0)
        {
            node *pointer = root;

            //move through trie creating new nodes for each letter
            for (int c = 0; c < index ; c++)
            {
                int x = word[c] - 97;
                if (word[c] == '\'')
                {
                    x = 26;
                }


                if (pointer -> children[x] == NULL)
                {
                    node *child = calloc(1,sizeof(node));
                    if (child == NULL)
                    {
                        return false;
                    }
                    pointer -> children[x] = child;
                    pointer = child;
                    if (c == index-1)
                    {
                        pointer ->is_word = true;
                        word_count++;
                    }
                }
                //move pointer to newly created node
                else
                {
                    pointer = pointer -> children[x];
                }


            }
            index = 0;
        }
    }
    fclose(dict);
    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    if (word_count > 0)
    {
        return word_count;
    }
    else
    {
        return 0;
    }
}

/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void)
{
    free_pointer(root);
    return true;
}

void free_pointer(node *pointer)
{
    for (int i = 0; i <27; i++)
    {
        if(pointer -> children[i] != NULL)
        {
            free_pointer(pointer -> children[i]);
        }
    }
    free(pointer);
}