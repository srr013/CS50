/**
 * helpers.c
 *
 * Helper functions for Problem Set 3.
 */

#include <cs50.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */

bool search(int value, int values[], int n)
{
    if (n > 0)
    {
        int middle_digit = n/2;
        int lower_bound = 0;
        int upper_bound = n;
        int check_value = values[middle_digit];
        int difference = upper_bound - lower_bound;
        if (check_value == value)
        {
            return true;
        }
        else if (check_value != value)
        {
            while (difference > 1)
            {
                if(value > check_value)
                {
                    lower_bound = middle_digit;
                    middle_digit = middle_digit + ((upper_bound - middle_digit)/2);
                    check_value = values[middle_digit];
                    difference = upper_bound - lower_bound;
                    if (check_value == value)
                    {
                        return true;
                        break;
                    }
                }

                else if(value < check_value)
                {
                    upper_bound = middle_digit;
                    middle_digit = middle_digit - (middle_digit/2)-1;
                    check_value = values[middle_digit];
                    difference = upper_bound - lower_bound;
                    if (check_value == value)
                    {
                        return true;
                        break;
                    }
                }
                else
                {
                    return false;
                    break;
                }
            }
        }
    return false;
    }
   else
    {
        return false;
    }

}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    int sort_array[65536] = {0};
    for (int x = 0; x < n; x++)
    {
        int integer = values[x];
        sort_array[integer] = sort_array[integer] + 1;
    }

    int y = 0;

    for (int x = 0; x < 65536; x++)
    {

        if (sort_array[x] > 0)
        {
            int i = 0;
            for (i = 0; i < sort_array[x]; i++)
            {
                values[y] = x;
                y++;

            }
        }
    }



}
