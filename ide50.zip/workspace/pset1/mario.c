#include <stdio.h>
#include <cs50.h>

int get_height(void);
void print_blocks(int i, int n);
int check_height(void);

int main(void)
{
    int n = check_height();
    int i = 1;
    int j = n - 1;

    while (i < n + 1)
    {
        print_blocks(i, j);
        i++;
        j--;
    }

}


int check_height(void)
{
    int height = get_int("Height: ");
    if (height <= 23 && height >= 0)
    {
        return height;
    }
    else
    {
        return check_height();
    }

}

void print_blocks(int i, int n)
{
    int c = 0;

    while (c < n)
    {
        printf(" ");
        c++;
    }

    c = 0;

    while (c < i)
    {
        printf("#");
        c++;
    }

    printf("  ");

    c = 0;

    while (c < i)
    {
        printf("#");
        c++;
    }

    c = 0;

    while (c < n - 1)
    {
        printf(" ");
        c++;
    }

    printf("\n");

}