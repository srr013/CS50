#include <stdio.h>
#include <cs50.h>

int water_bottles(int n);

int main(void)
{
    printf("For how many minutes do you shower:");
    int minutes = get_int();

    int total_water = water_bottles(minutes);

    printf("You use %i bottles per shower!\n", total_water);
}

int water_bottles(int n)
{
    return n*12;
}