#include <stdio.h>
#include <cs50.h>
#include <ctype.h>

long long get_number(void);
int sum_digits(long long n);
string card_type(long long n);


int main(void)
{
    long long card_number = get_number();
    if (sum_digits(card_number) == true)
    {
        printf("%s\n", card_type(card_number));
    }
    else
    {
        printf("INVALID\n");
    }
    card_type(card_number);

}

long long get_number(void)
{
    long long card_number = get_long_long("Number: ");
    return card_number;
}

int sum_digits(long long n)
{
    int j = 0;
    int p = 0;

    while (1 < n)
    {
        p = p + ((n % 10)); //add these together for the odd sequence
        n = n/10;
        if ((n % 10)*2 > 9)
        {
            j = j + 1 + (((n % 10)*2) % 10); //add 1 to accomodate the tens digit from mod 2
        }
        else
        {
        j = j + ((n % 10)*2); //multiply numebrs less than 10 for the even sequence
        }
        n = n/10;
    }

    int card_total = p + j;

    if (card_total % 10 == 0)
    {
        return true;
    }
    else
    {
        return false;
    }

}

string card_type(long long n)
{
    while (n > 100)
    {
        n = n/10;
    }

    if (n == 37 || n == 34)
    {
        return "AMEX";
    }
    else if (n > 50 && n < 56)
    {
        return "MASTERCARD";
    }
    else if (n > 39 && n < 50)
    {
        return "VISA";
    }
    else
    {
        return "INVALID";
    }
}