from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_session import Session
from passlib.apps import custom_app_context as pwd_context
from tempfile import mkdtemp
import datetime

from helpers import *

# configure application
app = Flask(__name__)

# ensure responses aren't cached
if app.config["DEBUG"]:
    @app.after_request
    def after_request(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Expires"] = 0
        response.headers["Pragma"] = "no-cache"
        return response

# custom filter
app.jinja_env.filters["usd"] = usd

# configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

#datetime help taken from https://www.saltycrane.com/blog/2008/06/how-to-get-current-date-and-time-in/
now = datetime.datetime.now()

@app.route("/")
@login_required
def index():
    stock_info, user_info, account_total = index_data()
    return render_template("index.html", stock_info=stock_info, user_info=user_info, account_total=account_total)


def index_data():
    stock_info = db.execute("SELECT *,SUM(num_shares) from 'transactions' WHERE user_id= :user_id GROUP BY ticker", user_id=session["user_id"])
    user_info = db.execute("SELECT * from 'users' WHERE id = :id", id=session["user_id"])
    account_total = user_info[0]["cash"]

    #get current data for each stock and add a dictionary key/value for it
    for stock in stock_info:
        ticker = stock["ticker"]
        stock_data = lookup(ticker)
        current_price = float(stock_data["price"])
        stock["current_price"] = current_price
        stock["value_holding"] = round((stock["SUM(num_shares)"] * current_price),2)
        account_total += float(current_price*stock["SUM(num_shares)"])

    account_total = round(account_total,2)
    user_info[0]["cash"]= round(user_info[0]["cash"],2)
    return (stock_info, user_info, account_total)

@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock."""

    stock_info, user_info, account_total = index_data()

    if request.method == "POST":
        if not request.form.get("ticker"):
            return apology(top = "No ticker entered")


        num_shares=request.form.get("num_shares")
        if not num_shares:
            return apology(top = "No shares entered")
        if float(num_shares) < 0:
            return apology(top = "Shares must be a positive number")

        # get current stock price
        new_ticker = request.form["ticker"]
        new_stock_info = lookup(new_ticker)
        if not new_stock_info:
            return apology(top = "invalid ticker")

        # check to see if the user has enough money
        stock_price = float(new_stock_info["price"])
        cost_stock = round(float(num_shares)*stock_price,2)
        available_money = user_info[0]["cash"]

        if available_money > cost_stock:
            # "buy" the stock by adding a line to the transaction table
            db.execute("INSERT INTO transactions (ticker, num_shares, stock_price, user_id, date) VALUES(:ticker, :num_shares, :price, :user_id, :date)",ticker=new_ticker, num_shares=num_shares, price = stock_price, user_id = session["user_id"], date = now)
            # decrement available cash by cost of stock
            remaining_money = available_money - cost_stock
            db.execute("UPDATE 'users' SET cash = :remaining_money where id = :user_id", remaining_money=remaining_money, user_id=session["user_id"])

        # not enough money
        else:
            return apology(top = "Not enough cash available")


        # redirect user to home page after transaction
        return redirect(url_for("index"))

    # send user to buy page when GET action in use
    else:
        return render_template("buy.html", stock_info=stock_info, user_info=user_info, account_total=account_total)

@app.route("/history")
@login_required
def history():
    """Show history of transactions."""
    stock_info = db.execute("SELECT * from 'transactions' WHERE user_id= :user_id", user_id=session["user_id"])
    user_info = db.execute("SELECT * from 'users' WHERE id = :id", id=session["user_id"])
    account_total = round(user_info[0]["cash"],2)
    user_info[0]["cash"]= round(user_info[0]["cash"],2)

    return render_template("history.html", stock_info=stock_info, user_info=user_info, account_total=account_total)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in."""

    # forget any user_id
    session.clear()

    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")

        # ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password")

        # query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

        # ensure username exists and password is correct
        if len(rows) != 1 or not pwd_context.verify(request.form.get("password"), rows[0]["hash"]):
            return apology("invalid username and/or password")

        # remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # redirect user to home page
        return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out."""

    # forget any user_id
    session.clear()

    # redirect user to login form
    return redirect(url_for("login"))

@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    if request.method == "POST":
        if not request.form["ticker"]:
            return apology(top = "enter ticker")
        else:
            ticker = request.form["ticker"]
            stock_info = lookup(ticker)
            if not stock_info:
                return apology(top = "not a valid ticker")
            else:
                return render_template("quoted.html", stock_info = stock_info)

    else:
        return render_template("quote.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user."""

    #for POST actions check registration data and register user if valid
    if request.method == "POST":
        #check that username, pw, and pw check fields are filled in.
        if not request.form["username"]:
            return apology(top = "Y No Username?", bottom= ":(((")
        elif not request.form["password"]:
            return apology(top = "Y No PW?", bottom= ":(((")
        elif not request.form["repeat_password"] or request.form["repeat_password"] != request.form["password"]:
            return apology(top = "PW Mistmatch", bottom= ":(((")

        #register user if username isn't taken
        else:
            # query database for username
            rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

            #if username doesnt exist
            if not rows:
                #create hash of password
                hash = pwd_context.hash(request.form["password"])

                #store data
                db.execute("INSERT INTO users (username, hash) VALUES(:username, :hash)", username=request.form["username"], hash = hash)

                # query database for username
                rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

                # remember which user has logged in
                session["user_id"] = rows[0]["id"]

                # redirect user to home page
                return redirect(url_for("index"))

            #if username exists
            else:
                return apology(top = "Username Taken", bottom= ":(((")

    #show registration screen for GET actions
    else:
        return render_template("register.html")



@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock."""

    stock_info, user_info, account_total = index_data()

    if request.method == "POST":

        if not request.form["ticker"]:
            return apology(top = "Y No ticker?", bottom= ":(((")
        elif not request.form["num_shares"]:
            return apology(top = "Indicate # of shares", bottom= ":(((")

        #set num_shares to negative and validate
        num_shares=-float(request.form.get("num_shares"))
        if num_shares > 0:
            return apology(top = "shares to sell must be a positive number")

        # get current stock data for sale
        ticker = request.form["ticker"]
        sell_stock_info = lookup(ticker)
        if not sell_stock_info:
            return apology(top = "invalid ticker")


        # find stock sale price to add to account
        sell_price = round(sell_stock_info["price"],2)
        update_cash = sell_price * abs(float(num_shares))
        size = len(stock_info)

        for i in stock_info:
            #return apology if number of shares is too high
            if ticker == i["ticker"] and abs(num_shares) > i["SUM(num_shares)"]:
                return apology(top = "You don't own that many shares")

            elif ticker == i["ticker"] and abs(num_shares) <= i["SUM(num_shares)"]:
                db.execute("INSERT INTO transactions (ticker, num_shares, stock_price, user_id, date) VALUES(:ticker, :num_shares, :stock_price, :user_id, :date)",ticker=ticker, num_shares=num_shares, stock_price = sell_price, user_id = session["user_id"], date=now)
                db.execute("UPDATE 'users' SET cash = cash + :update_cash where id = :user_id", update_cash=update_cash, user_id=session["user_id"])
                break

            elif i == size-1 and ticker != i["ticker"]:
                return apology(top = "Invalid ticker")



        # redirect user to home page
        return redirect(url_for("index"))

    else:
        return render_template("sell.html", stock_info=stock_info, user_info=user_info, account_total=account_total)
