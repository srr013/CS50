#personal auth token and SID for Twilio, as well as sender phoner number
TWILIO_AUTH_TOKEN = "d00c816c8b601bd6fccfd9eb0d1cced9"
TWILIO_SID = "AC36319f94132108199532bb04d8333903"
SENDER_PHONE = "+14145017012"